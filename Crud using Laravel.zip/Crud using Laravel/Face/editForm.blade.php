@extends('Face.frame')
@section('body')
	<div class="container">
		<div class="card">
			<div class="card-header bg-info text-white">
				<h3>Edit Form</h3>
			</div>
			<div class="card-body">
				<fieldset>	
					<form method="post" action="{{url('update')}}">
						@csrf
						<p>
							<label>Name</label>
							<input type="hidden" name="id" value="{{$data->id}}">
							<input class="form-control form-sm" type="text" value="{{$data->bookName}}" name="name">
						</p>
						<p>
							<label>Language</label>
							<input class="form-control form-sm " type="text" value="{{$data->bookPrice}}" name="price">
						</p>
						 
						<p>
							<input type="submit" name="submit" value="Update" class="btn btn-xs btn-info">
						</p>
					</form>
				</fieldset>
			</div>
		</div>
		
	</div>
@endsection 
