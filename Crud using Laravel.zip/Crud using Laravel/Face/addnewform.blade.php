@extends('Face.frame')
@section('body')
<div class="container">
		<div class="card card-primary">
			<div class="card-header bg-primary text-white">
				<h4>Add New Form</h4>
			</div>
			<div class="card-body">
				<fieldset>	
					<form method="post" action="{{url('addNew')}}" enctype="mulitpart/form-data">
						@csrf
						<p>
							<label>Book Name</label> 
							<input class="form-control form-sm" type="text"   name="name">
						</p>
						<p>
							<label>Book Price</label>
							<input class="form-control form-sm " type="text"  name="price">
						</p>
						 
						<p>
							<input type="submit" name="submit" value="Add new" class="btn btn-sm btn-primary">
						</p>
					</form>
				</fieldset>
			</div>
		</div>
		
	</div>
@endsection