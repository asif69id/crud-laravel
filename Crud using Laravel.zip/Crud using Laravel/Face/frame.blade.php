<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>@yield('title', 'empty')</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<style type="text/css">
		.table{
			font-family: calibri;  
		}
		tbody tr td{
			padding: 0pt;
		}
		.card{
			width: 50%;
		}
		.btn{
			
		}
	</style>
</head>
<body>  
	<br>
	
	<br>
	@yield('body')

</body>
</html>