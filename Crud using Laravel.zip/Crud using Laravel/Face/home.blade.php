@extends('Face.frame')
@section('body')
<div class="container">
	 <div class=" ">
		<a href="addNewForm" class="btn btn-info btn-sm">
		<b>Add New Record</b>
		</a>
	</div>
	 <br>
	<div class="  	">
		<table class="table table-sm table-bordered table-warning">
			<thead class="thead-dark">
				<th>#</th>
				<th>Book Name</th>
				<th>Book Price</th>
			 
				<th>Action</th>
			</thead>
			<tbody class="tbody">      
				@foreach($data as $row)
				<tr>
					<th>{{$row->id}}</th>
					<td>{{$row->bookName}}</td>
					<td><span class="text-danger">$ </span>{{$row->bookPrice}}  </td>
					 
					<td>
						<form method="get" action="{{url('edit')}}">@csrf
							<input type="hidden" name="editId" value="{{$row->id}}">
							 
							<button type="submit" value="Edit" class="btn btn-sm btn-success">
								<b>Edit</b>
							</button>
						<!-- <a href="edit/{{$row->id}}" class="btn btn-xs btn-success">Edit</a> -->
						&nbsp;
						<a href="delete/{{$row->id}}" class="btn btn-sm btn-danger">
							<b>Delete</b>
						</a></form>
						</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
 @endsection