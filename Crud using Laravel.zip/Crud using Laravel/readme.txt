---Import the file books.sql in database name "laravel"---
Database Name : "laravel";
Table Name : "books";
Resource view files :
	All files will be in the folder named (Face)->(resource/view/Face/)
	1. frame.blade.php(For layout)
	2.addnewform.blade.php(for adding new data)
	3.editForm.blade.php(for editing)
	4.home.blade.php(for display)
Paste  "FACE folder" in resource/view folder 
Copy controller and model 
---Thank you-----
[Developer ---Asif amin] 
